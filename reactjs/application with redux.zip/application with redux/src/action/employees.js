import axios from "axios";

const _addEmployee=(emp)=>({
    type : 'ADD_EMPLOYEE',
    emp
});

export const addEmployee=(empData={
    name:'',
    password:'',
    email:'',
    address:''
})=>{
    return (dispatch)=>{
        const employee={
            name:empData.name,
            password:empData.password,
            email:empData.email,
            address:empData.address 
        };

        return axios.post("http://localhost:10000/springbootfirstproject/create",employee).then(result=>{
            dispatch(_addEmployee(result.data))
        })
    }
}

const _getEmployeeList=(emp)=>({
    type : 'SHOW_ALLEMPLOYEE',
    emp
});

export const getEmployees=()=>{
    return (dispatch)=>{
        return axios.get("http://localhost:10000/springbootfirstproject/showAll").then(result=>{
            const employees=[];

            result.data.forEach(item=>{
                employees.push(item);
            });
            dispatch(_getEmployeeList(employees));
        }
    }

}
