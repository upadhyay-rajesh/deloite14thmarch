import { Component } from "react";

import EmployeeService from './EmployeeService';

class RegisterComponent extends Component {
    
    constructor(props){
        super(props);
    
        this.state = { 
            id1:'',
            name:'',
            password:'',
            email:'',
            address:''

        } 
        this.changeId1Handler=this.changeId1Handler.bind(this);
    }

    changeId1Handler(event){
        this.setState({id1:event.target.value});
    }

    changeNameHandler=(event)=>{
        this.setState({name:event.target.value});
    }

    changePasswordHandler=(event)=>{
        this.setState({password:event.target.value});
    }

    changeEmailHandler=(event)=>{
        this.setState({email:event.target.value});
    }

    changeAddressHandler=(event)=>{
        this.setState({address:event.target.value});
    }

    saveOrUpdateEmployee=(e)=>{
        let employee={name:this.state.name,password:this.state.password,email:this.state.email,address:this.state.address};
        
        EmployeeService.createEmployee(employee).then(res=>{
            alert("registration success");
           
        })
        
        console.log("hello i am click event "+ JSON.stringify(employee));
    }

    render() { 
        return (
            <div>
                <div className="container">
                    <div className="row">
                        <div className="card col-md-6 offset-md-3 offset-md-3">

                        <div className="card-body">
                    <form>
                         <div className="form-group">
                             <label>ID:</label>
                             <input type="text" name="id1" value={this.state.id1} className="form-control" onChange={this.changeId1Handler}></input>
                        </div>
                        <div className="form-group">
                             <label>Name:</label>
                             <input type="text" name="name" value={this.state.name} className="form-control" onChange={this.changeNameHandler}></input>
                             </div>
                        <div className="form-group">
                            <label>Password:</label><input type="password" name="password" value={this.state.password} onChange={this.changePasswordHandler} className="form-control"></input>
                            </div>
                        <div className="form-group">
                             <label>Email:</label><input type="email" name="email" value={this.state.email} className="form-control" onChange={this.changeEmailHandler}></input>
                             </div>
                        <div className="form-group">
                             <label>Address:</label><input type="text" name="address" value={this.state.address} className="form-control" onChange={this.changeAddressHandler}></input>
                             </div>
                        <div>
                            <button type="button" className="btn btn-success" onClick={this.saveOrUpdateEmployee}>Register</button><button className="btn btn-danger">Cancle</button>
                        </div>
                       
                    </form>
                    </div></div>
                    </div>
                </div>
            </div>
        );
    }
}
 
export default RegisterComponent;