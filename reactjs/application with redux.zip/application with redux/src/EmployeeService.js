import axios from 'axios';

const url="http://localhost:10000/springbootfirstproject";

class EmployeeService{
    createEmployee(emp){
        return axios.post(url+"/create",emp);
    }

    getAllEmployee(){
        return axios.get(url+"/showAll");
    }

    getEmployeeById(empid){
        return axios.get(url+"/viewProfile/"+empid);
    }
    updateEmployee(emp,empid){
        return axios.put(url+"/editProfile/"+empid,emp);
    }

    deleteEmployee(empid){
        return axios.delete(url+"/deleteProfile/"+empid);
    }
}

export default new EmployeeService();