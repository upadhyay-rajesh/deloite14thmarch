import { Component } from "react";

class LoginComponent extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                i am login
                <h1>{this.props.mydata}</h1>
            </div>
        );
    }
}
 
export default LoginComponent;