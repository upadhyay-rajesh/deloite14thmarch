const employeeReducerDefaultState =[];
export default (state=employeeReducerDefaultState,action)=>{
    switch(action.type){
        case 'ADD_EMPLOYEE':
            return [
                ...state,
                action.employee
            ];
            case 'SHOW_ALLEMPLOYEE':
                return action.employees;
            
            default:
                return state;
    }
};