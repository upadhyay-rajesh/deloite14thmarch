import { Component } from "react";

class FooterComponent extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                copyright reserve
            </div>
        );
    }
}
 
export default FooterComponent;