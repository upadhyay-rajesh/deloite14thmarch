import { Component } from "react";
import ShowAllEmployee from "./showAllEmployee";

class HeaderComponent extends Component {
    state = {  } 

    addEmployee=()=>{
        this.props.history.push('/addemp');
    }

    ListAllEmployee=()=>{
        this.props.history.push('/');
    }

    render() { 
        return (
            <div>
                <h1>Employee Management System</h1>
                <ShowAllEmployee registerUser={this.addEmployee} displayuser={this.ListAllEmployee}/>
            </div>
        );
    }
}
 
export default HeaderComponent;