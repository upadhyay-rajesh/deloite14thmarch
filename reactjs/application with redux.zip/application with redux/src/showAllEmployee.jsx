import { Component } from "react";
import EmployeeService from './EmployeeService';
import LoginComponent from "./login";
import {connect } from 'react-redux';

class  ShowAllEmployee extends Component {
    constructor(props){
        super(props);

        this.state = {  
            employees:[],
            username:'Samiksha'
        } 

        //this.deleteEmployee=this.deleteEmployee.bind(this);
    
    }

    const mapStateToProps=(state)=>{
        return {
           employees :state
        }
    }
/*
    componentDidMount(){
        EmployeeService.getAllEmployee().then(res=>{
            this.setState({employees:res.data});
            
        })
    }
*/
    deleteEmployee(email){
        EmployeeService.deleteEmployee(email).then(res=>{
            this.setState({employees:this.state.employees.filter(e=>e.email!==email)});
        })
    }

   viewEmployee=(empid)=>{
        this.props.history.push(`/vieemp/${empid}`);
    }

   

    editEmployee=(empid)=>{
        this.props.history.push(`/editemp/${empid}`);
    }


    render() { 
        return (

            <div>
                
                <div>
                 <button className="btn btn-primary" onClick={()=>this.props.registerUser()}>Add Employee</button>
                 <button className="btn btn-primary" onClick={()=>this.props.displayuser()}>List All Employee</button>
                </div>
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Password</th>
                            <th>Email</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.employees.map(emp=>
                                <tr>
                                    <td>{emp.name}</td>
                                    <td>{emp.password}</td>
                                    <td>{emp.email}</td>
                                    <td>{emp.address}</td>
                                    <td><button type="button" onClick={()=>this.deleteEmployee(emp.email)}>delete</button><button type="button" onClick={()=>this.viewEmployee(emp.email)}>view</button><button type="button" onClick={()=>this.editEmployee(emp.email)}>edit</button></td>
                                </tr>
                                )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}
 
export default connect(mapStateToProps)(ShowAllEmployee);