import { Component } from "react";
import EmployeeService from "./EmployeeService";

class ViewComponent extends Component {
    constructor(props){
        super(props);
    
        this.state = { 
          
            email:this.props.match.params.empid,
            employees:''
           

        } 
    }

    componentDidMount(){
        EmployeeService.getEmployeeById(this.state.email).then(res=>{
            this.setState({employees:res.data});
            
        })
    }

    render() { 
        return (
            <div>
                 <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Password</th>
                            <th>Email</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            //this.state.employees.map(emp=>
                                <tr>
                                    <td>{this.state.employees.name}</td>
                                    <td>{this.state.employees.password}</td>
                                    <td>{this.state.employees.email}</td>
                                    <td>{this.state.employees.address}</td>
                                </tr>
                              //  )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}
 
export default ViewComponent;