import { applyMiddleware, createStore } from "redux";
import thunk from 'redux-thunk';
import employees from '../reducer/employees';

export default ()=>{
    return createStore(employees, applyMiddleware(thunk));
}