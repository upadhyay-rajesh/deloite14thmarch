import logo from './logo.svg';
import './App.css';
import { Route, BrowserRouter as Router ,Switch } from 'react-router-dom';

import HeaderComponent from './header';
import FooterComponent from './footer';
import ShowAllEmployee from './showAllEmployee';
import RegisterComponent from './register';
import EditComponent from './EditComponent';
import ViewComponent from './VieComponent';
//import Form1 from 'Form.jsx';

function App() {
  return (
    <div className="App">
      <Router>
        <HeaderComponent />
          <div>
            <Switch>
              <Route path="/" exact component={ShowAllEmployee}></Route>
              <Route path="/addemp" exact component={RegisterComponent}></Route>
              <Route path="/editemp/:empid" exact component={EditComponent}></Route>
              <Route path="/vieemp/:empid" exact component={ViewComponent}></Route>
            </Switch>
          </div>
        <FooterComponent />
       
      </Router>
    </div>
  );
}

export default App;
