import { Component } from "react";

class HomeComponent extends Component {
    state = {  } 


    loginuser=(empid)=>{
        this.props.history.push(`/login`);
    }

   

    registerUser=(empid)=>{
        this.props.history.push(`/register`);
    }

    render() { 
        return (
            <div>
                 <div>
                 <button className="btn btn-primary" onClick={()=>this.registerUser()}>Register</button>
                 <button className="btn btn-primary" onClick={()=>this.loginuser()}>Login</button>
                </div>
            </div>
        );
    }
}
 
export default HomeComponent;