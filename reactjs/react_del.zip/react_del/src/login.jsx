import { Component } from "react";

class LoginComponent extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                i am login page
            </div>
        );
    }
}
 
export default LoginComponent;