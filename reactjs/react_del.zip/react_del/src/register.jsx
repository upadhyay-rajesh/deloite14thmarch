import { Component } from "react";

class RegisterComponent extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                Name : <input type="text"></input> <br></br>
                Password : <input type="password"></input> <br></br>
                <input type="button" value="Register"></input>
            </div>
        );
    }
}
 
export default RegisterComponent;