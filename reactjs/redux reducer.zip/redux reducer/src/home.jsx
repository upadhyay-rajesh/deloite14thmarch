import { Component } from "react";

class HomeComponent extends Component {
    state = {  } 


    loginuser=()=>{
        this.props.history.push(`/login`);
    }

   

    registerUser=()=>{
        this.props.history.push(`/register`);
    }

    displayAllRecord=()=>{
        this.props.history.push(`/displayAll`);
    }

    render() { 
        return (
            <div>
                 <div>
                 <button className="btn btn-primary" onClick={()=>this.registerUser()}>Register</button>
                 <button className="btn btn-success" onClick={()=>this.loginuser()}>Login</button>
                 <button className="btn btn-danger" onClick={()=>this.displayAllRecord()}>Display All Record</button>
                </div>
            </div>
        );
    }
}
 
export default HomeComponent;