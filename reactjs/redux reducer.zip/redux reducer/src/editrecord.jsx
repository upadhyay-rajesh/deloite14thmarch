import { Component } from "react";
import EmployeeService from "./EmployeeService";

class EditRecordComponent extends Component {
    state = { 
        id:this.props.match.params.id,
        name:'',
        password:'',
        email:'',
        address:'',
        
     } 
     changeNameHandler=(event)=>{
        this.setState({name:event.target.value});
    }
    changePasswordHandler=(event)=>{
       this.setState({password:event.target.value});
   }
   changeEmailHandler=(event)=>{
       this.setState({email:event.target.value});
   }
   changeAddressHandler=(event)=>{
       this.setState({address:event.target.value});
   }

    componentDidMount(){
        EmployeeService.getEmployeeById(this.state.id).then(res=>{
            let employee=res.data;
            this.setState({name:employee.name,password:employee.password,email:employee.email,address:employee.address});
        })
    }

    editRecord=(e)=>{
        let employee={name:this.state.name,password:this.state.password,email:this.state.email,address:this.state.address}
        console.log("employee record is --> "+JSON.stringify(employee));

        EmployeeService.editEmployeeRecord(employee,this.state.id).then(res=>{
            this.props.history.push(`/displayAll`);
        })

    }

    render() { 
        return (
            <div>
                <h3>Edit Record</h3>
                <div>
                <form>
                Name : <input type="text" value={this.state.name} onChange={this.changeNameHandler}></input> <br></br>
                Password : <input type="password" value={this.state.password} onChange={this.changePasswordHandler}></input> <br></br>
                Email : <input type="email" value={this.state.email} onChange={this.changeEmailHandler}></input> <br></br>
                Address : <input type="text" value={this.state.address} onChange={this.changeAddressHandler}></input> <br></br>
                <input type="button" value="Register" onClick={this.editRecord}></input>
                </form>
                </div>
            </div>
        );
    }
}
 
export default EditRecordComponent;