import { Component } from "react";
import EmployeeService from "./EmployeeService";

class DisplayAllRecordComponent extends Component {
    state = { 
        employees:[]
     } 

    componentDidMount(){ //this is lifecycle method like init it automatically execute en component ll be loaded
                         //this is kno as Hook also

        EmployeeService.getAllRecord().then(res=>{
            console.log(res.data);
            this.setState({employees:res.data})
        })

    }

    editEmployee=(id)=>{
        this.props.history.push(`/editEmployee/${id}`);
    }
    viewEmployee=(id)=>{
        this.props.history.push(`/viewEmployee/${id}`);
    }
    deleteEmployee=(id)=>{
        EmployeeService.deleteRecord(id).then(res=>{
            this.setState({employees:this.state.employees.filter(emp=>emp.email!==id)});
        })
    }

    render() { 
        return (
            <div className="row">
                <table className="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Password</th>
                            <th>Email</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.employees.map(emp1=>
                                <tr>
                                    <td>{emp1.name}</td>
                                    <td>{emp1.password}</td>
                                    <td>{emp1.email}</td>
                                    <td>{emp1.address}</td>
                                    <td>
                                        <button className="btn btn-primary" onClick={()=>this.editEmployee(emp1.email)}>update</button>
                                        <button className="btn btn-info" onClick={()=>this.deleteEmployee(emp1.email)}>delete</button>
                                        <button className="btn btn-danger" onClick={()=>this.viewEmployee(emp1.email)}>view</button>
                                    </td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}
 
export default DisplayAllRecordComponent;