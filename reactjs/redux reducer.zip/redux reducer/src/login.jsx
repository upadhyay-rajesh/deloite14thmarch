import { Component } from "react";

class LoginComponent extends Component {
    state = {  } 
    render() { 
        return (
            <div>
                i am login page

                {this.props.myid}
            </div>
        );
    }
}
 
export default LoginComponent;