import logo from './logo.svg';
import './App.css';
import RegisterComponent from './register';
import LoginComponent from './login';
import HomeComponent from './home';
import { Route, BrowserRouter as Router ,Switch } from 'react-router-dom';
import DisplayAllRecordComponent from './displayAll';
import EditRecordComponent from './editrecord';
import ViewRecordComponent from './viewRecord';

function App() {
  return (
    <div>
      <Router>
        
          <div>
            <Switch>
              <Route path="/" exact component={HomeComponent}></Route>
              <Route path="/register" exact component={RegisterComponent}></Route>
              <Route path="/login" exact component={LoginComponent}></Route>
              <Route path="/displayAll" exact component={DisplayAllRecordComponent}></Route>
              <Route path="/editEmployee/:id" exact component={EditRecordComponent}></Route>
              <Route path="/viewEmployee/:id" exact component={ViewRecordComponent}></Route>
             </Switch>
          </div>
        
       
      </Router>
    </div>
  );
}

export default App;
