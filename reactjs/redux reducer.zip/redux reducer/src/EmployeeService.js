import axios from 'axios';

const url="http://localhost:10000/whatsappboot";

class EmployeeService{
    createEmployeeRecord(emp){
        return axios.post(url+"/createProfile",emp);
    }

    getAllRecord(){
        return axios.get(url+"/allProfile");
    }
    getEmployeeById(id){
        return axios.get(url+"/viewProfile/"+id);
    }

    editEmployeeRecord(emp,id){
        return axios.put(url+"/editProfile/"+id,emp);
    }
    deleteRecord(id){
        return axios.delete(url+"/deleteProfile/"+id);
    }
}
export default new EmployeeService()