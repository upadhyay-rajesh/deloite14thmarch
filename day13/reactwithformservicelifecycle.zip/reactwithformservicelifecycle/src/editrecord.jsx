import { Component } from "react";

class EditRecordComponent extends Component {
    state = {  } 
    render() { 
        return (
            <div></div>
        );
    }
}
 
export default EditRecordComponent;