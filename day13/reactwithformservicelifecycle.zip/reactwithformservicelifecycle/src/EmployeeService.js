import axios from 'axios';

const url="http://localhost:10000/whatsappboot";

class EmployeeService{
    createEmployeeRecord(emp){
        return axios.post(url+"/createProfile",emp);
    }

    getAllRecord(){
        return axios.get(url+"/allProfile");
    }
    getEmployeeById(id){
        return axios.get(url+"/viewProfile/"+id);
    }
}
export default new EmployeeService()